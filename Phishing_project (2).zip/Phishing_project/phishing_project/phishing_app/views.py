from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import sys
import os
import pickle
import numpy as np
import json

# Ensure project root is in path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))
from feature import FeatureExtraction  # Import FeatureExtraction

# Load trained model from PHISHING_PROJECT directory
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODEL_PATH = os.path.join(BASE_DIR, "newmodel.pkl")

# Load the trained model
try:
    with open(MODEL_PATH, "rb") as file:
        model = pickle.load(file)
except Exception as e:
    print(f"Error loading model: {e}")
    model = None  # Prevent crashes if model is missing

def index(request):
    """Render the main webpage."""
    return render(request, "index.html")

@csrf_exempt  # Use CSRF token in production
def predict(request):
    """Handle predictions based on user input."""
    if request.method == "POST":
        try:
            # Parse JSON request
            data = json.loads(request.body)
            url = data.get("url")  # Extract URL from JSON request
            
            if not url:
                return JsonResponse({"error": "No URL provided"}, status=400)

            # Extract features from the URL
            obj = FeatureExtraction(url)
            features = np.array(obj.getFeaturesList()).reshape(1, -1)

            # Ensure model is loaded
            if model is None:
                return JsonResponse({"error": "Model not loaded"}, status=500)

            # Make prediction
            y_pred = model.predict(features)[0]
            confidence = model.predict_proba(features)[0]

            # Interpret results
            result = "✅ Safe website" if y_pred == 1 else "⚠️ Suspicious website detected"
            confidence_level = float(confidence[y_pred])  # Get confidence level

            return JsonResponse({"result": result, "confidence": confidence_level})

        except json.JSONDecodeError:
            return JsonResponse({"error": "Invalid JSON format"}, status=400)
        except Exception as e:
            return JsonResponse({"error": str(e)}, status=500)

    return JsonResponse({"error": "Invalid request method"}, status=400)
